#ifndef DIRECTEUR_RH_H
#define DIRECTEUR_RH_H

#include "personne.h"
#include "professionnel.h"

class _QX_DLL_EXPORT_GESTION_CONGES Directeur_RH : public Professionnel
{
public:
    void methodeAbstraite() override {};

    Directeur_RH(){};
    Directeur_RH(QString nom, QString prenom, Genre genre, QDate dateN, QString adresse, QString telephone,
                 QString matricule,QString profession, Status status, QString login, QString password,QString email)
                 :Professionnel(nom,prenom,genre,dateN,adresse,telephone,matricule,profession,status,login,password,email){;}

    virtual ~Directeur_RH(){};
};

QX_REGISTER_HPP_ENTITY(Directeur_RH,Personne,0)

typedef std::shared_ptr<Directeur_RH> drh_ptr;
typedef qx::QxCollection<long, Directeur_RH> liste_drh;
#endif // DIRECTEUR_RH_H
