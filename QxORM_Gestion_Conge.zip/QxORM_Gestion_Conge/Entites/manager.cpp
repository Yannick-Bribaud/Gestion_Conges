#include "Precompilation/precompilation.h"
#include "manager.h"
#include <QxOrm_Impl.h>

QX_REGISTER_CPP_ENTITY(Managers)

namespace qx {
template <> void register_class(QxClass<Managers> &Mng){

    Mng.setName("t_managers");
    Mng.data(&Managers::pf_matricule,"m_matricule");
    Mng.data(&Managers::pf_profession,"m_profession");
    Mng.data(&Managers::pf_status,"m_manager");
    Mng.data(&Managers::pf_login,"m_login");
    Mng.data(&Managers::pf_password,"m_password");
    Mng.data(&Managers::pf_email,"m_email");
}

}



