#ifndef EMPLOYE_H
#define EMPLOYE_H
#include "personne.h"
#include "professionnel.h"

class _QX_DLL_EXPORT_GESTION_CONGES Employe : public Professionnel
{
    QX_REGISTER_FRIEND_CLASS(Employe)

public:
    void methodeAbstraite() override {};

    Employe() {};
    Employe(QDate debutPeriode,QDate finPeriode, qint8 soldeConge,QString nom, QString prenom, Genre genre, QDate dateN, QString adresse, QString telephone,
            QString matricule,QString profession, Status status, QString login, QString password,QString email)
            :Professionnel(nom,prenom,genre,dateN,adresse,telephone,matricule,profession,status,login,password,email),
            e_debutPeriode(debutPeriode),e_finPeriode(finPeriode),e_soldeConge(soldeConge){};

    Employe(QString nom, QString prenom, Genre genre, QDate dateN, QString adresse, QString telephone,
            QString matricule,QString profession, Status status, QString login, QString password,QString email)
            :Professionnel(nom,prenom,genre,dateN,adresse,telephone,matricule,profession,status,login,password,email){};

    virtual ~Employe(){};

    //getters
    QDate getDebutPeriode() const {return e_debutPeriode;}
    QDate getFinPeriode() const {return e_finPeriode;}
    qint8 getSoldeCong() const {return e_soldeConge;}

    //setters
    void setDebutPeriode(const QDate & dateDebut) {e_debutPeriode = dateDebut;}
    void setFinPeriode(const QDate & dateFin) {e_finPeriode = dateFin;}
    void setSolde( qint8 & soldeConge) {e_soldeConge = soldeConge; }

private:
    QDate e_debutPeriode;
    QDate e_finPeriode;
    qint8 e_soldeConge;

};

QX_REGISTER_HPP_ENTITY(Employe,Personne,0);

typedef std::shared_ptr<Employe> employe_ptr;
typedef qx::QxCollection<long, Employe> liste_employe;
#endif // EMPLOYE_H
