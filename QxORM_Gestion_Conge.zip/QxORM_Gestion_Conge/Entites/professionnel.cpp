#include "Precompilation/precompilation.h"
#include "professionnel.h"
#include <QxOrm_Impl.h>


QX_REGISTER_CPP_ENTITY(Professionnel)

  //enregistrer la classe dans le context de QXORM
namespace  qx {
template <> void register_class(QxClass<Professionnel> & Pro)
 {
      Pro.setName("t_Professionnel");
      Pro.data(& Professionnel::pf_matricule, "_matricule" );
      Pro.data(& Professionnel::pf_profession,"_profession" );
      Pro.data(& Professionnel::pf_status,  "_status" );
      Pro.data(& Professionnel::pf_login,  "_login");
      Pro.data(& Professionnel::pf_password, "_password" );
      Pro.data(& Professionnel::pf_email, "_email" );
 }
}
