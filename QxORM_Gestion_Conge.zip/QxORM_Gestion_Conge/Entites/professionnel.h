#ifndef PROFESSIONNEL_H
#define PROFESSIONNEL_H

#include "personne.h"

class _QX_DLL_EXPORT_GESTION_CONGES Professionnel : public Personne
{
    QX_REGISTER_FRIEND_CLASS(Professionnel)

public:

    void methodeAbstraite() override {;}
    enum Status{Manager,Employe,Directeur_Ressources_Humaines,Administrateur};

    Professionnel() {};
    Professionnel(QString nom, QString prenom, Genre genre, QDate dateN, QString adresse, QString telephone,
                  QString matricule,QString profession, Status status, QString login, QString password,QString email)
                  :Personne(nom,prenom,genre,dateN,adresse,telephone),pf_matricule(matricule),pf_profession(profession),
                   pf_status(status),pf_login(login),pf_password(password),pf_email(email){};

    virtual ~Professionnel(){};

    //getters
    QString getMatricule() const { return pf_matricule; }
    QString getProffession() const {return pf_profession; }
    Status getStatus() const {return  pf_status;}
    QString getLoging() const {return pf_login;}
    QString getPassword() const {return pf_password;}
    QString getEmail() const {return  pf_email; }

    //setters
    void setMatricule(const QString & matricule) {pf_matricule = matricule;}
    void setProfession(const QString & profession) {pf_profession = profession;}
    void setStatus(const Status & status) {pf_status = status;}
    void setLogin(const QString & login) { pf_login = login;}
    void setPassword(const QString & password) {pf_password = password;}
    void setEmail(const QString & email) {pf_email = email;}

protected:

    QString pf_matricule;
    QString pf_profession;
    Status  pf_status;
    QString pf_login;
    QString pf_password;
    QString pf_email;

};

QX_REGISTER_HPP_ENTITY(Professionnel,Personne,0);

typedef std::shared_ptr<Professionnel> professnel_ptr;
typedef qx::QxCollection<long, Professionnel> liste_professionnel;
#endif // PROFESSIONNEL_H
