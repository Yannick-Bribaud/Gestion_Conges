#ifndef MANAGER_H
#define MANAGER_H
#include "personne.h"
#include "professionnel.h"


class _QX_DLL_EXPORT_GESTION_CONGES Managers : public Professionnel
{

public:
     void methodeAbstraite() override {};

    Managers(){};
    Managers(const QString & nom, const QString & prenom, Genre genre, QDate dateN, const QString & adresse, const QString & telephone,
            const QString & matricule, const QString & profession, Status status, const QString & login, const QString & password, const QString & email)
            :Professionnel(nom,prenom,genre,dateN,adresse,telephone,matricule,profession,status,login,password,email){};

    virtual ~Managers(){};

};

QX_REGISTER_HPP_ENTITY(Managers,Personne,0)

typedef std::shared_ptr<Managers> Mngr_ptr;
typedef QList<Managers> liste_mngr;
#endif // MANAGER_H
