#ifndef DEMANDE_H
#define DEMANDE_H


class _QX_DLL_EXPORT_GESTION_CONGES Demande
{
    QX_REGISTER_FRIEND_CLASS(Demande)

public:

      Demande(){};
      Demande(qint8 dureeConge, const QString & matricule_exp, const QString & matricule_dest, const QDate & date_soumission, const QTime & heure_soumission, const QString & corps_demande )
              :dmd_dureeConge(dureeConge),dmd_matricule_exp(matricule_exp),dmd_matricule_dest(matricule_dest),dmd_date_soumission(date_soumission),dmd_heure_soumission(heure_soumission),dmd_corps(corps_demande){};
      Demande(qint8 dureeConge, const QString & matricule_exp, const QString & matricule_dest, const QDate & date_soumission, const QTime & heure_soumission)
              :dmd_dureeConge(dureeConge),dmd_matricule_exp(matricule_exp),dmd_matricule_dest(matricule_dest),dmd_date_soumission(date_soumission),dmd_heure_soumission(heure_soumission){};

      virtual ~Demande(){};

private:

    long dmd_id;
    qint8 dmd_dureeConge;
    QString dmd_matricule_exp;
    QString dmd_matricule_dest;
    QDate dmd_date_soumission;
    QTime dmd_heure_soumission;
    QString dmd_corps;

};

QX_REGISTER_HPP_ENTITY(Demande,qx::trait::no_base_class_defined,0)

typedef std::shared_ptr<Demande> dmnd_ptr;
typedef qx::QxCollection<long, Demande> liste_dmand;
#endif // DEMANDE_H
