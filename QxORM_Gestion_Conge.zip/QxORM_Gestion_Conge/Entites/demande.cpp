#include "Precompilation/precompilation.h"
#include "demande.h"
#include <QxOrm_Impl.h>

QX_REGISTER_CPP_ENTITY(Demande)

namespace qx {

    template <> void register_class(QxClass<Demande> & Dmd){

        Dmd.setName("t_demande(Conges)");
        Dmd.id(&Demande::dmd_id,"d_id");
        Dmd.data(&Demande::dmd_date_soumission,"d_soumission_(date)");
        Dmd.data(&Demande::dmd_heure_soumission, "d_soumission_(heure)");
        Dmd.data(&Demande::dmd_dureeConge, "d_duree_conge");
        Dmd.data(&Demande::dmd_matricule_exp, "d_matricule_expdtr");
        Dmd.data(&Demande::dmd_matricule_dest, "d_matricule_recptr");
    }

}
