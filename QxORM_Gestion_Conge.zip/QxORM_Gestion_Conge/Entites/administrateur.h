#ifndef ADMINISTRATEUR_H
#define ADMINISTRATEUR_H

#include "personne.h"
#include "professionnel.h"

class _QX_DLL_EXPORT_GESTION_CONGES Administrateur : public Professionnel
{

public:

    void methodeAbstraite() override {};
    Administrateur(){};
    Administrateur(QString nom, QString prenom, Genre genre, QDate dateN, QString adresse, QString telephone,
                   QString matricule,QString profession, Status status, QString login, QString password,QString email)
                   :Professionnel(nom,prenom,genre,dateN,adresse,telephone,matricule,profession,status,login,password,email){;}
    virtual ~Administrateur() {};
};


QX_REGISTER_HPP_ENTITY(Administrateur,Personne,0);

typedef std::shared_ptr<Administrateur> admin_ptr;
typedef qx::QxCollection<long, admin_ptr> liste_admin;
#endif // ADMINISTRATEUR_H
