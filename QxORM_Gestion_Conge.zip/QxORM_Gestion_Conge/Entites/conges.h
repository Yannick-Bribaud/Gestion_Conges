#ifndef CONGES_H
#define CONGES_H


class _QX_DLL_EXPORT_GESTION_CONGES Conges
{
    QX_REGISTER_FRIEND_CLASS(Conges)

public:

    Conges(){};
    Conges(QDate debutConge, qint8 duree, QDate finConge):c_debutConge(debutConge),c_duree(duree),c_finConge(finConge){};
    Conges(QString test_1,QString test_2):c_test_1(test_1), c_test_2(test_2){};

    virtual ~Conges(){};

    //getters
    long getId() const { return  c_id; }
    QDate getDebutConge() const { return c_debutConge;}
    qint8 getDuree() const { return c_duree; }
    QDate getFinConge() const { return c_finConge; }


    //settters
    void setId(long identifiant) { c_id = identifiant; }
    void setDebutConge(const QDate & DebutConge) {c_debutConge = DebutConge;}
    void setDuree(const qint8 & dureeConge) {c_duree = dureeConge; }
    void setFinConge(const QDate & finConge) { c_finConge = finConge; }

private:

    long  c_id;
    QDate c_debutConge;
    qint8 c_duree;
    QDate c_finConge;

    QString c_test_1;
    QString c_test_2;

};

QX_REGISTER_HPP_ENTITY(Conges,qx::trait::no_base_class_defined,0)

typedef std::shared_ptr<Conges> conges_ptr;
typedef std::vector<conges_ptr>liste_conges;
#endif // CONGES_H
