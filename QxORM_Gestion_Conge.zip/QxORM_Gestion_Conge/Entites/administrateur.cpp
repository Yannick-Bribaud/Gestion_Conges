#include "Precompilation/precompilation.h"
#include "administrateur.h"
#include <QxOrm_Impl.h>


QX_REGISTER_CPP_ENTITY(Administrateur)

namespace qx {

  template <> void register_class(QxClass<Administrateur> &Admin){

        Admin.data(&Administrateur::pf_matricule, "a_matricule");
        Admin.data(&Administrateur::pf_profession, "a_profession");
        Admin.data(&Administrateur::pf_status, "a_status");
        Admin.data(&Administrateur::pf_login, "a_login");
        Admin.data(&Administrateur::pf_password, "a_password");
        Admin.data(&Administrateur::pf_email, "a_email");

    }
}
