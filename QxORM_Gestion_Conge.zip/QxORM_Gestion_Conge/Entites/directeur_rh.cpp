#include "Precompilation/precompilation.h"
#include "directeur_rh.h"
#include <QxOrm_Impl.h>

QX_REGISTER_CPP_ENTITY(Directeur_RH)

namespace qx {
    template <>void register_class(QxClass<Directeur_RH> & DRH){
        DRH.data(&Directeur_RH::pf_matricule, "d_matricule");
        DRH.data(&Directeur_RH::pf_profession,"d_profession");
        DRH.data(&Directeur_RH::pf_status, "d_status");
        DRH.data(&Directeur_RH::pf_login, "d_login");
        DRH.data(&Directeur_RH::pf_password, "d_password");
        DRH.data(&Directeur_RH::pf_email, "d_email");

    }
}
