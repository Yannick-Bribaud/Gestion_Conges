#include "Precompilation/precompilation.h"
#include "personne.h"
#include <QxOrm_Impl.h>

QX_REGISTER_CPP_ENTITY(Personne)

  //enregistrer la classe dans le context de QXORM
namespace  qx {
template <> void register_class(QxClass<Personne> & P)
 {
      P.setName("t_Personne");
      P.id(& Personne::p_id, "_id" );
      P.data(& Personne::p_nom, "_nom" );
      P.data(& Personne::p_prenom,"_prenom" );
      P.data(& Personne::p_genre,  "_genre" );
      P.data(& Personne::p_dateNaissance,"_dateNaissance" );
      P.data(& Personne::p_adresse, "_adresse" );
      P.data(& Personne::p_telephone, "_telephone" );
 }
}
