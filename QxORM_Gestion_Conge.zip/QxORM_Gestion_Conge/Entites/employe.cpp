#include "Precompilation/precompilation.h"
#include "employe.h"
#include <QxOrm_Impl.h>

QX_REGISTER_CPP_ENTITY(Employe)

namespace qx {

    template<> void register_class(QxClass<Employe> & Emp){

        Emp.data(&Employe::pf_matricule,"e_matricule");
        Emp.data(&Employe::pf_profession,"e_profession");
        Emp.data(&Employe::pf_status, "e_status");
        Emp.data(&Employe::pf_login, "e_login");
        Emp.data(&Employe::pf_password, "e_password");
        Emp.data(&Employe::pf_email, "e_email");
        Emp.data(&Employe::e_debutPeriode,"e_debutPeriode");
        Emp.data(&Employe::e_finPeriode,"e_finPeriode");
        Emp.data(&Employe::e_soldeConge, "e_soldeConge");

    }
}
