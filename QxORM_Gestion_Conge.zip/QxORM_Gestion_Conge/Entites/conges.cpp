#include "Precompilation/precompilation.h"
#include "conges.h"
#include <QxOrm_Impl.h>


QX_REGISTER_CPP_ENTITY(Conges)

namespace qx {
    template <> void register_class(QxClass<Conges> & Cng){

    Cng.setName("t_conge");
    Cng.id(&Conges::c_id, "c_id");
    Cng.data(&Conges::c_debutConge, "c_debutConges");
    Cng.data(&Conges::c_duree, "c_dureeConge");
    Cng.data(&Conges::c_finConge, "c_finConge");
    Cng.data(&Conges::c_test_1, "test_1");
    Cng.data(&Conges::c_test_2, "test_2");
}

}
