#include <QDebug>
#include <QApplication>
#include "Qx_Connect_db/basedonnees.h"
#include "Entites/conges.h"



int main(int argc, char *argv[])
{
    QApplication a(argc, argv);



    try {

        BaseDeDonnee * bd=BaseDeDonnee::getInstance();
        bool rs=bd->estConnecte();
        qDebug()<<"resultat" <<rs;

        QDate date(2021,04,13);
        QDate dateX(2011,05,14);
        QDate dateq(2001,07,12);
        QDate dateqx(2011,06,19);

        // changé les arguments de la classe conges Juste pour le test
        conges_ptr conge; conge.reset(new Conges("vanta","nanotuple"));
        conges_ptr conges; conges.reset(new Conges("Black","nanotuple"));

        liste_conges list;
        list.push_back(conge);
        list.push_back(conges);
        QSqlError daoError = qx::dao::insert(list);


    }  catch (dbError e) {
        qDebug()<<e.getMessage();
    }


    BaseDeDonnee::detruireInstance();


    return a.exec();
}
