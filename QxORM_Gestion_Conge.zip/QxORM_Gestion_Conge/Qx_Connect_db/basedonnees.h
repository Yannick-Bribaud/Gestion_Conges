#ifndef BASEDONNEES_H
#define BASEDONNEES_H

#include <QtSql/QtSql>
#include <QtSql/QSqlDatabase>
#include <QtSql/QSqlQuery>
#include <QMutex>
#include <QString>
#include <QSqlError>
#include "Exceptions/dbExceptions/dberror.h"

class  BaseDeDonnee :public QObject,public QException
{
    Q_OBJECT

public:
    static BaseDeDonnee * getInstance();
    static void detruireInstance();
    bool estConnecte();
    bool connecter(QString nomBase, QString username, QString password, QString serveur);
    bool connecterQx(QString nomBase, QString username, QString password, QString serveur);
    bool connectOpen();
    void closeDataBase();

private:
   BaseDeDonnee();
   virtual ~BaseDeDonnee(){};

   dbError * exception;
   static BaseDeDonnee *  baseDeDonnees;
   static QString typeDB;
   static int nbre_Acces;
   QSqlDatabase db;
   QMutex mutex;
};


#endif // BASEDONNEES_H
