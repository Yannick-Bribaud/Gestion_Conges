#include "basedonnees.h"

BaseDeDonnee* BaseDeDonnee::baseDeDonnees = NULL;
QString BaseDeDonnee::typeDB = "QMYSQL";
int BaseDeDonnee::nbre_Acces = 0;


BaseDeDonnee *BaseDeDonnee::getInstance()
{
    if(baseDeDonnees == NULL)
    {
        baseDeDonnees = new BaseDeDonnee();
    }

       nbre_Acces++;
       return baseDeDonnees;
}

void BaseDeDonnee::detruireInstance()
{
    if(baseDeDonnees != NULL){
        if (nbre_Acces > 0){
             nbre_Acces--;
         }
       if(nbre_Acces == 0){
          delete baseDeDonnees;
          baseDeDonnees = NULL;
       }
    }
}

bool BaseDeDonnee::estConnecte()
{
    QMutexLocker verrou(&mutex);
    return db.isOpen();
}

bool BaseDeDonnee::connecter(QString nomBase, QString username, QString password, QString serveur){

    if(typeDB != "QMYSQL"){
       throw dbError(db.lastError().text());
      }
        QMutexLocker verrou(&mutex);

        if(!db.isOpen()){

           db.setHostName(serveur);
           db.setUserName(username);
           db.setPassword(password);
           db.setDatabaseName(nomBase);

           if(db.open()){return true;}
           else{
            throw dbError(db.lastError().text());
           }
        }
        else
            return true;
}


bool BaseDeDonnee::connectOpen(){
    return db.open();
}

void BaseDeDonnee::closeDataBase(){
    db.close();
}


BaseDeDonnee::BaseDeDonnee(){
  db = QSqlDatabase::addDatabase(typeDB);
  connecter("qxorm","root","","localhost");
}




