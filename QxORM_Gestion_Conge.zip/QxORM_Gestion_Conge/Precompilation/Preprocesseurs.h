#ifndef _QX_PREPROCESSEURS_H
#define _QX_PREPROCESSEURS_H

/*
    Pour accelerer l'étape de compilation, il est preferable de définir les préprocesseurs
    dans ce fichier, il sera executé en premier et permettra de gagner du temps de compilation
*/

#ifdef _QX_BUILD_GESTION_CONGES
#define _QX_DLL_EXPORT_GESTION_CONGES   QX_DLL_EXPORT_HELPER
#else
#define _QX_DLL_EXPORT_GESTION_CONGES QX_DLL_IMPORT_HELPER
#endif // _QX_BUILD_GESTION_CONGES

#ifdef _QX_BUILD_GESTION_CONGES
#define QX_REGISTER_HPP_ENTITY  QX_REGISTER_HPP_EXPORT_DLL
#define QX_REGISTER_CPP_ENTITY  QX_REGISTER_CPP_EXPORT_DLL
#else
#define QX_REGISTER_HPP_ENTITY  QX_REGISTER_HPP_IMPORT_DLL
#define QX_REGISTER_CPP_ENTITY  QX_REGISTER_CPP_IMPORT_DLL
#endif // _QX_BUILD_GESTION_CONGES

#endif // _QX_PREPROCESSEURS_H
