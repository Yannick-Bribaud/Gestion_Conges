#ifndef PRECOMPILATION_H
#define PRECOMPILATION_H

#include <QxOrm.h>
#include "Preprocesseurs.h"

#endif // PRECOMPILATION_H
