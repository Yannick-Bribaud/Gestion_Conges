#ifndef MODELCONGESEMPLOYE_H
#define MODELCONGESEMPLOYE_H
#include "Entites/employe.h"
#include "Entites/personne.h"
#include "Entites/manager.h"

class Managers;

class _QX_DLL_EXPORT_GESTION_CONGES ModelCongesEmploye : public Employe
{
    QX_REGISTER_FRIEND_CLASS(ModelCongesEmploye)
public:
    void methodeAbstraite() override {};


    ModelCongesEmploye(){};
    virtual ~ModelCongesEmploye(){};

private:
    typedef std::shared_ptr<Managers>mngr_ptr;
    mngr_ptr m_manager;

};

QX_REGISTER_HPP_ENTITY(ModelCongesEmploye,Personne,0)

typedef std::shared_ptr<ModelCongesEmploye> model_ptr;
typedef qx::QxCollection<long, ModelCongesEmploye> liste_modelCngeEmpl;

#endif // MODELCONGESEMPLOYE_H
