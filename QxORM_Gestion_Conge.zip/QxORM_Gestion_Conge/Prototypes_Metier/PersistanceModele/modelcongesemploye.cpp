#include "Precompilation/precompilation.h"
#include "modelcongesemploye.h"
#include "Entites/manager.h"
#include <QxOrm_Impl.h>

QX_REGISTER_CPP_ENTITY(ModelCongesEmploye)

namespace qx {

template <> void register_class(QxClass<ModelCongesEmploye> & Model){

        Model.data(&Employe::pf_matricule,"mdl_matricule");
        Model.data(&Employe::pf_profession,"mdl_profession");
        Model.data(&Employe::pf_status, "mdl_status");
        Model.data(&Employe::pf_login, "mdl_login");
        Model.data(&Employe::pf_password, "mdl_password");
        Model.data(&Employe::pf_email, "mdl_email");
        Model.data(&Employe::e_debutPeriode,"mdl_debutPeriode");
        Model.data(&Employe::e_finPeriode,"mdl_finPeriode");
        Model.data(&Employe::e_soldeConge, "mdl_soldeConge");

        Model.relationManyToOne(&ModelCongesEmploye::m_manager,"m_matricule");
 }
}
