#ifndef DBERROR_H
#define DBERROR_H

#include <QString>
#include <QException>
#include <QSqlError>

class dbError : public QException
{

public:
    dbError(QString message);
    QString getMessage() const;

private:
    QString message;
};

#endif // DBERROR_H
