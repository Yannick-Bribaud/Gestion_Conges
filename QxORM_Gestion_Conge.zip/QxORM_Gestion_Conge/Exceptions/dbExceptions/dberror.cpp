#include "dberror.h"

dbError::dbError(QString message){
    this->message=message;
}

QString dbError::getMessage() const{
    return message;
}
